import React, { useEffect, useMemo, useState } from "react";
import { motion } from "framer-motion";
import { BookOpen, Brain, CheckCircle2, Clock, Flame, LineChart as LineChartIcon, PlayCircle, Settings, Target } from "lucide-react";
import { ResponsiveContainer, LineChart as RLineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, BarChart, Bar, Legend } from "recharts";

type SkillKey = "comunicacion" | "trabajo_en_equipo" | "liderazgo" | "pensamiento_critico" | "gestion_tiempo" | "adaptabilidad" | "inteligencia_emocional" | "resolucion_conflictos" | "presentacion";

type Skill = { key: SkillKey; nombre: string; descripcion: string };

const SKILLS: Skill[] = [
  { key: "comunicacion", nombre: "Comunicación", descripcion: "Claridad, escucha activa y síntesis." },
  { key: "trabajo_en_equipo", nombre: "Trabajo en equipo", descripcion: "Colaboración y coordinación." },
  { key: "liderazgo", nombre: "Liderazgo", descripcion: "Dirección, motivación, delegación." },
  { key: "pensamiento_critico", nombre: "Pensamiento crítico", descripcion: "Análisis, criterio y argumentación." },
  { key: "gestion_tiempo", nombre: "Gestión del tiempo", descripcion: "Priorización y planificación." },
  { key: "adaptabilidad", nombre: "Adaptabilidad", descripcion: "Flexibilidad ante el cambio." },
  { key: "inteligencia_emocional", nombre: "Inteligencia emocional", descripcion: "Autogestión y empatía." },
  { key: "resolucion_conflictos", nombre: "Resolución de conflictos", descripcion: "Mediación y negociación." },
  { key: "presentacion", nombre: "Presentación", descripcion: "Estructura y presencia escénica." },
];

const SCENARIOS: Record<SkillKey, string[]> = {
  comunicacion: [
    "Explica en 90 segundos una idea compleja para público no experto.",
    "Haz preguntas abiertas para clarificar un malentendido de equipo."
  ],
  trabajo_en_equipo: [
    "Coordina tareas usando el método RACI para un mini-proyecto.",
    "Da crédito público a un colega por su aporte."
  ],
  liderazgo: [
    "Facilita una reunión de 15 min con agenda y acuerdos.",
    "Delegar: asigna tarea con contexto, objetivo y criterios de éxito."
  ],
  pensamiento_critico: [
    "Identifica supuestos y riesgos de una decisión reciente.",
    "Esboza 3 alternativas y sus trade-offs."
  ],
  gestion_tiempo: [
    "Planifica mañana con técnica Timeboxing (3 bloques).",
    "Aplica la regla 2 minutos para 5 pendientes."
  ],
  adaptabilidad: [
    "Aplica un plan B ante un cambio inesperado de alcance.",
    "Aprende una función nueva de tu herramienta habitual."
  ],
  inteligencia_emocional: [
    "Practica respiración 4-7-8 antes de dar feedback.",
    "Escribe un registro ABC (acontecimiento, creencia, consecuencia)."
  ],
  resolucion_conflictos: [
    "Usa el marco DESC para una conversación difícil.",
    "Mapea intereses vs posiciones en un desacuerdo."
  ],
  presentacion: [
    "Ensaya una introducción de 60s con gancho y objetivo.",
    "Simplifica 3 diapositivas a una sola con mensaje clave."
  ],
};

const initialScores: Record<SkillKey, number> = {
  comunicacion: 50, trabajo_en_equipo: 50, liderazgo: 50, pensamiento_critico: 50, gestion_tiempo: 50,
  adaptabilidad: 50, inteligencia_emocional: 50, resolucion_conflictos: 50, presentacion: 50,
};

const store = {
  get<T>(k: string, fb: T): T { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) as T : fb; } catch { return fb; } },
  set<T>(k: string, v: T) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} }
};

const pretty = (k: SkillKey) => SKILLS.find(s => s.key === k)?.nombre ?? k;

export default function App() {
  const [tab, setTab] = useState<"diagnostico"|"practica"|"retos"|"progreso"|"biblioteca">("diagnostico");
  const [scores, setScores] = useState<Record<SkillKey, number>>(() => store.get("softskills:scores", initialScores));
  const [focus, setFocus] = useState<SkillKey>(() => store.get("softskills:focus", "comunicacion"));
  const [notes, setNotes] = useState<string>(() => store.get("softskills:notas", ""));
  const [streak, setStreak] = useState<number>(() => store.get("softskills:streak", 0));
  const [dailyDone, setDailyDone] = useState<boolean>(() => store.get("softskills:doneToday", false));
  const [goal, setGoal] = useState<string>(() => store.get("softskills:goal", "Mejorar mi comunicación en 30 días con prácticas diarias de 10 minutos."));
  const [smart, setSmart] = useState<{S:boolean;M:boolean;A:boolean;R:boolean;T:boolean}>({S:true,M:true,A:true,R:true,T:true});
  const [autoChallenge, setAutoChallenge] = useState<boolean>(() => store.get("softskills:autoChallenge", true));
  const [challenge, setChallenge] = useState<string>("");

  useEffect(() => setChallenge(randomChallenge("comunicacion")), []);
  useEffect(() => { store.set("softskills:scores", scores); }, [scores]);
  useEffect(() => { store.set("softskills:focus", focus); }, [focus]);
  useEffect(() => { store.set("softskills:notas", notes); }, [notes]);
  useEffect(() => { store.set("softskills:streak", streak); }, [streak]);
  useEffect(() => { store.set("softskills:doneToday", dailyDone); }, [dailyDone]);
  useEffect(() => { store.set("softskills:goal", goal); }, [goal]);
  useEffect(() => { store.set("softskills:autoChallenge", autoChallenge); }, [autoChallenge]);
  useEffect(() => { if (autoChallenge) setChallenge(randomChallenge(focus)); }, [focus, autoChallenge]);

  const radarData = useMemo(() => SKILLS.map(s => ({ skill: s.nombre, score: scores[s.key] })), [scores]);

  const progressData = useMemo(() => {
    const days = 10;
    return Array.from({ length: days }).map((_, i) => ({
      day: `D${i + 1}`,
      progreso: Math.round((Object.values(scores).reduce((a, b) => a + b, 0) / (SKILLS.length)) * (0.8 + i * 0.02))
    }));
  }, [scores]);

  function randomChallenge(skill: SkillKey) {
    const items = SCENARIOS[skill];
    return items[Math.floor(Math.random() * items.length)];
  }

  function markDone() {
    if (dailyDone) return;
    setDailyDone(true);
    setStreak(s => s + 1);
    setScores(prev => ({ ...prev, [focus]: Math.min(100, prev[focus] + 2) }));
  }

  function resetDay() {
    setDailyDone(false);
  }

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-white to-slate-50 text-slate-900 p-6">
      <div className="max-w-6xl mx-auto">
        <header className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-3xl font-bold tracking-tight">Sonqollay – Coach de Habilidades Blandas</h1>
            <p className="text-sm text-slate-600">Entrena, mide y mejora tus soft skills con prácticas breves y feedback.</p>
          </div>
          <span className="badge text-base"><Flame className="inline mr-2 h-4 w-4"/>Racha: {streak} días</span>
        </header>

        <div className="grid grid-cols-5 gap-2 mb-6">
          {tabBtn("diagnostico", "Diagnóstico", <Brain className="h-4 w-4 mr-2"/> )}
          {tabBtn("practica", "Práctica", <PlayCircle className="h-4 w-4 mr-2"/>)}
          {tabBtn("retos", "Retos", <Target className="h-4 w-4 mr-2"/>)}
          {tabBtn("progreso", "Progreso", <LineChartIcon className="h-4 w-4 mr-2"/>)}
          {tabBtn("biblioteca", "Biblioteca", <BookOpen className="h-4 w-4 mr-2"/>)}
        </div>

        {/* Resto igual al prototipo entregado */}
        {/* Diagnóstico */}
        <div className="space-y-4" style={{ display: tab==="diagnostico" ? "block" : "none" }}>
          <div className="card p-4">
            <h2 className="text-lg font-semibold">Autoevaluación rápida</h2>
            <p className="text-sm text-slate-600 mb-4">Ajusta tu nivel percibido (0–100) para cada habilidad. Define una <strong>habilidad foco</strong>.</p>
            <div className="grid md:grid-cols-2 gap-6">
              {SKILLS.map(s => (
                <div key={s.key} className="p-3 rounded-xl border bg-white">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <div className="font-semibold">{s.nombre}</div>
                      <div className="text-xs text-slate-500">{s.descripcion}</div>
                    </div>
                    <button className={`btn ${focus===s.key?'btn-primary':'btn-secondary'}`} onClick={() => setFocus(s.key)}>Foco</button>
                  </div>
                  <div className="flex items-center gap-3">
                    <div className="w-24 text-sm">Nivel: {scores[s.key]}</div>
                    <input className="w-full" type="range" min={0} max={100} value={scores[s.key]} onChange={(e)=>setScores({...scores, [s.key]: Number(e.target.value)})} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="card p-4">
            <h2 className="text-lg font-semibold">Mapa de habilidades</h2>
            <p className="text-sm text-slate-600">Visualiza tu perfil actual y detecta brechas.</p>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <RadarChart data={radarData} outerRadius={90}>
                  <PolarGrid />
                  <PolarAngleAxis dataKey="skill" tick={{ fontSize: 11 }} />
                  <PolarRadiusAxis angle={90} domain={[0, 100]} />
                  <Radar dataKey="score" stroke="#0ea5e9" fill="#0ea5e9" fillOpacity={0.3} />
                </RadarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Práctica */}
        <div className="space-y-4" style={{ display: tab==="practica" ? "block" : "none" }}>
          <div className="card p-4">
            <h2 className="text-lg font-semibold flex items-center gap-2"><PlayCircle className="h-5 w-5"/> Sesión diaria ({new Date().toLocaleDateString()})</h2>
            <p className="text-sm text-slate-600 mb-3">Habilidad foco: <strong>{pretty(focus)}</strong>. Completa el reto, reflexiona y registra tu práctica.</p>

            <div className="flex items-center justify-between bg-white p-4 rounded-xl border">
              <div>
                <div className="text-sm text-slate-500">Reto sugerido</div>
                <div className="text-lg font-medium">{challenge}</div>
              </div>
              <div className="flex items-center gap-3 text-sm">
                <label className="flex items-center gap-2">
                  <input type="checkbox" checked={autoChallenge} onChange={(e)=>setAutoChallenge(e.target.checked)} />
                  Automático
                </label>
                <button className="btn btn-secondary" onClick={()=>setChallenge(randomChallenge(focus))}>Otro</button>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4 mt-4">
              <div className="bg-white p-4 rounded-xl border">
                <div className="font-semibold mb-2">Registro de práctica</div>
                <textarea className="textarea" placeholder="¿Qué hiciste? ¿Qué salió bien? ¿Qué mejorarás?" value={notes} onChange={(e)=>setNotes(e.target.value)} />
                <div className="flex items-center gap-3 mt-3">
                  <button className="btn btn-primary" onClick={markDone} disabled={dailyDone}>
                    <CheckCircle2 className="h-4 w-4 mr-2"/> {dailyDone ? "Práctica registrada" : "Registrar práctica"}
                  </button>
                  {dailyDone and <button className="btn btn-secondary" onClick={resetDay}>Reiniciar día</button>}
                </div>
              </div>

              <div className="bg-white p-4 rounded-xl border">
                <div className="font-semibold mb-2">Feedback rápido (rúbrica 1–5)</div>
                <Rubric onChange={(delta)=>setScores(prev => ({...prev, [focus]: Math.min(100, Math.max(0, prev[focus] + delta))}))} />
                <div className="mt-4">
                  <div className="progress"><span style={{width: scores[focus] + '%'}}></span></div>
                  <div className="text-sm text-slate-600 mt-1">Puntaje actual en {pretty(focus)}: <strong>{scores[focus]}</strong></div>
                </div>
              </div>
            </div>
          </div>

          <div className="card p-4">
            <h2 className="text-lg font-semibold">Objetivo SMART</h2>
            <p className="text-sm text-slate-600">Usa el objetivo como guía y verifica sus criterios.</p>
            <div className="grid md:grid-cols-3 gap-4">
              <div className="md:col-span-2 space-y-2">
                <input className="input" value={goal} onChange={(e)=>setGoal(e.target.value)} />
                <div className="grid grid-cols-5 gap-2 text-sm">
                  {([["S","Específico"],["M","Medible"],["A","Alcanzable"],["R","Relevante"],["T","Temporal"]] as const).map(([k,label]) => (
                    <label key={k} className="flex items-center gap-2 border rounded-xl p-2">
                      <input type="checkbox" checked={(smart as any)[k]} onChange={(e)=>setSmart({...smart, [k]: e.target.checked})} />
                      <span>{label}</span>
                    </label>
                  ))}
                </div>
              </div>
              <div className="bg-slate-50 rounded-xl p-3 text-sm">
                <p className="font-medium">Sugerencia</p>
                <p>“Durante 30 días, practicaré {pretty(focus).toLowerCase()} 10 minutos diarios y pediré feedback a 1 persona por semana. Éxito = elevar mi puntuación +15.”</p>
              </div>
            </div>
          </div>
        </div>

        {/* Retos */}
        <div className="card p-4" style={{ display: tab==="retos" ? "block" : "none" }}>
          <h2 className="text-lg font-semibold">Banco de retos por habilidad</h2>
          <p className="text-sm text-slate-600 mb-4">Elige una habilidad para generar prácticas concretas.</p>
          <div className="grid md:grid-cols-3 gap-3">
            {SKILLS.map(s => (
              <motion.div key={s.key} whileHover={{ scale: 1.02 }} className="border rounded-xl p-3 bg-white flex flex-col gap-2">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-semibold">{s.nombre}</div>
                    <div className="text-xs text-slate-500">{s.descripcion}</div>
                  </div>
                  <button className="btn btn-secondary" onClick={()=>{ setFocus(s.key); setChallenge(SCENARIOS[s.key][0]); setTab("practica"); }}>Practicar</button>
                </div>
                <ul className="list-disc list-inside text-sm text-slate-700 space-y-1">
                  {SCENARIOS[s.key].map((t, i) => <li key={i}>{t}</li>)}
                </ul>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Progreso */}
        <div className="space-y-4" style={{ display: tab==="progreso" ? "block" : "none" }}>
          <div className="card p-4">
            <h2 className="text-lg font-semibold">Vista de progreso</h2>
            <p className="text-sm text-slate-600">Tendencia general de tu entrenamiento.</p>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <RLineChart data={progressData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="day" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="progreso" stroke="#22c55e" dot={false} />
                </RLineChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="card p-4">
            <h2 className="text-lg font-semibold">Comparativa por habilidad</h2>
            <p className="text-sm text-slate-600">Revisa tus puntajes actuales en cada habilidad.</p>
            <div className="h-72">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={SKILLS.map(s => ({ name: s.nombre, score: scores[s.key] }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" tick={{ fontSize: 11 }} />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="score" fill="#6366f1" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        </div>

        {/* Biblioteca */}
        <div className="card p-4" style={{ display: tab==="biblioteca" ? "block" : "none" }}>
          <h2 className="text-lg font-semibold">Biblioteca de microaprendizajes</h2>
          <p className="text-sm text-slate-600">Conceptos clave y guías prácticas en 1 minuto.</p>
          <div className="grid md:grid-cols-3 gap-3 mt-3">
            {[
              { t: "Feedback SBI", d: "Situación–Comportamiento–Impacto: describe sin juicios, concreta un ejemplo y el efecto observado." },
              { t: "DESC para conversaciones difíciles", d: "Describe, Expresa, Sugiere, Consecuencia. Mantén el foco en la conducta, no en la persona." },
              { t: "Timeboxing", d: "Agenda bloques con inicio/fin y un objetivo claro; protege tu atención con pausas." },
              { t: "Escucha activa", d: "Parafrasea, valida emociones, pregunta antes de responder." },
              { t: "Reuniones efectivas", d: "Agenda, propósito, 3 decisiones; cierra con responsables y plazos." },
              { t: "Elevator pitch", d: "Problema–Solución–Valor–Llamado a la acción en 60–90s." },
            ].map((item, idx) => (
              <div key={idx} className="rounded-xl border p-4 bg-white">
                <div className="font-semibold mb-1">{item.t}</div>
                <div className="text-sm text-slate-600">{item.d}</div>
              </div>
            ))}
          </div>
        </div>

        <footer className="mt-8 flex items-center justify-between text-xs text-slate-500">
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4"/>
            <span>Sesiones cortas (10–15 min) • Evidencia en notas y rúbrica</span>
          </div>
          <div className="flex items-center gap-2">
            <Settings className="h-4 w-4"/>
            <span>Datos guardados localmente</span>
          </div>
        </footer>
      </div>
    </div>
  );

  function tabBtn(v: typeof tab, label: string, icon: React.ReactNode) {
    return (
      <button onClick={()=>setTab(v)} className={`btn ${tab===v?'btn-primary':'btn-secondary'} w-full`}>
        {icon}{label}
      </button>
    );
  }
}

function Rubric({ onChange }: { onChange: (delta: number) => void }) {
  const [vals, setVals] = useState([3,3,3,3]);
  const criterios = [
    { k: "Claridad", d: "Mensaje directo y comprensible" },
    { k: "Evidencia", d: "Ejemplos y datos" },
    { k: "Escucha", d: "Atención y validación" },
    { k: "Impacto", d: "Relevancia y utilidad" },
  ];
  useEffect(() => {
    const total = vals.reduce((a,b) => a+b, 0);
    const delta = Math.round((total - 12) * 0.8);
    onChange(delta);
  }, [vals]);

  return (
    <div className="space-y-3">
      {criterios.map((c, i) => (
        <div key={c.k} className="grid grid-cols-5 gap-2 items-center">
          <div className="col-span-2 text-sm">
            <div className="font-medium">{c.k}</div>
            <div className="text-xs text-slate-500">{c.d}</div>
          </div>
          <div className="col-span-3">
            <input type="range" min={1} max={5} step={1} value={vals[i]} onChange={(e)=>setVals(vs => vs.map((x, idx)=> idx===i? Number(e.target.value): x))} className="w-full" />
            <div className="text-xs text-slate-600 mt-1">Nivel: {vals[i]}</div>
          </div>
        </div>
      ))}
    </div>
  );
}
