# Publicar Sonqollay en Vercel + DonDominio

1) Sube esta carpeta a un repo en GitHub.
2) En Vercel: **Add New Project → Import**. Framework: Vite. Build: `npm run build`. Output: `dist/`.
3) En tu proyecto (Vercel) agrega los dominios `sonqollay.com` y `www.sonqollay.com`.
4) En DonDominio añade DNS:
- A `@` → 76.76.21.21
- CNAME `www` → cname.vercel-dns.com.
(Con punto final en DonDominio).

5) Espera unos minutos a la propagación y prueba https://sonqollay.com
