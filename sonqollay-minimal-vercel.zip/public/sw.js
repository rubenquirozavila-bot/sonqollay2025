self.addEventListener('install', (e) => {
  e.waitUntil(caches.open('softskills-v1').then((cache) => cache.addAll(['/','/index.html','/manifest.webmanifest'])));
});
self.addEventListener('fetch', (e) => {
  e.respondWith((async () => {
    try { return await fetch(e.request); }
    catch { const cached = await caches.match(e.request); return cached || caches.match('/'); }
  })());
});